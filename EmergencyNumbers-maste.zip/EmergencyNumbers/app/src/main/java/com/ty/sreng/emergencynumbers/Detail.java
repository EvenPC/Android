package com.ty.sreng.emergencynumbers;

import com.example.easylinuxcomander2.R;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class Detail extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_detail);
		Bundle extra=getIntent().getExtras();
		String main=extra.getString("main");
		String detail=extra.getString("detail");
		TextView tv_main=(TextView)findViewById(R.id.txtMain);
		TextView tv_detail=(TextView)findViewById(R.id.txtDetail);
		tv_main.setText(main);
		tv_detail.setText(detail);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.detail, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_call) {
			
			//Intent intent=new Intent(Intent.ACTION_DIAL,Uri.parse("tel:098750"));
			//startActivity(intent);
			Intent email = new Intent(Intent.ACTION_SEND);
            email.putExtra(Intent.EXTRA_EMAIL, new String[]{"srengty.pc@gmail.com"});             
            email.setType("message/rfc822");              
            startActivity(Intent.createChooser(email, "Select Email Client"));
			return true;
			
		}
		return super.onOptionsItemSelected(item);
	}
}
